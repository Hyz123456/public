<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='10988';
$userkey='d54c91908f34ba50c9f76dbde1825f3d04e85cdc';
?>
