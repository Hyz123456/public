<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='10886';
$userkey='1b5745912dd5295f1be2631e0a9b8ed6017ddde1';
?>
